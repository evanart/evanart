=== WP Category Sticky Posts ===
Contributors: beezeee
Donate link: http://www.workinginboxershorts.com/wp-category-sticky-set-sticky-posts-for-individual-category-archives
Tags: category, sticky posts
Requires at least: 2.9.1
Tested up to: 3.2.1
Stable tag: tags/0.13

Allows you to set Sticky posts for individual category archives.

== Description ==

After installing and activating, there will be a Category Sticky meta box on the Edit Post page. Add categories where you want the post you're editing to be sticky and update the post, and you're done.

When displayed as sticky posts in a category listing, posts will have a 'category_sticky_post' class added to them for additional styling.

Note that this plugin uses the "the_posts" filter. This means you can set a post sticky for a category that it doesn't belong to, and it will show on that category when the archive is viewed.

Sidebar widgets will also reflect the sticky order when an archive is being viewed.

For help or other plugins, find me at http://www.workinginboxershorts.com


== Installation ==

The easiest way is via Plugins->Add New from the left sidebar of your WP Admin, just search for category sticky posts.
