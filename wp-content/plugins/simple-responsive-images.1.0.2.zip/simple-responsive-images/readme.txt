=== Simple Responsive Images ===
Contributors: Rahe
Donate link: http://www.beapi.fr/donate/
Tags: images, image, responsive images, responsive, content
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 1.0.1

== Description ==

This plugin generate images with attributes for the responsive images in your content.
Choose the breakpoints and the sizes associated. 
The next images you will insert and the elements generated with the wp_attachement functions will begenerated with the right attributes.

Contribute on https://github.com/Rahe/Simple-responsive-images
Based on http://www.grahambird.co.uk/lab/doubletake/ for javascript


== Installation ==
 **PHP5 Required.**
 
1. Download, unzip and upload to your WordPress plugins directory
2. Activate the plugin within you WordPress Administration Backend
3. Go to Settings > Reponsive Images
4. Configure the breakpoints and the html element of the resizing.
5. Insert one image in your content with the uploader.
6. Go n your post and try to resize the window
7. Let the magic work !

== Screenshots ==

1. Settings page

== Changelog ==
* 1.0
	* First release
* 1.0.1
	* Debug the admin
	* Right activation call
	* More tests before making actions
* 1.0.2
	* Add the name for the html_selector field buggy !
	* Documentation